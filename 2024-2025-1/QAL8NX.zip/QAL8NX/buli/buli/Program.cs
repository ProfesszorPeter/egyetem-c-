﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace buli
{
    internal class Program
    {
        struct adatok
        {
            public string nev;
            public int viz;
            public int uccsi;
            public int sor;
            public int bor;
            public int rovid;
        }
        static void Main(string[] args)
        {
            string[] test = new string[3];
            StreamReader adatok = new StreamReader("szilveszter2019.txt");
            string sor = adatok.ReadLine();
            int index  =0;
            while (sor != null) {
                Console.WriteLine(sor);
                sor = adatok.ReadLine();
                test[index] = sor;
                index++;
            }
            Console.ReadKey();
        }
    }
}
